Alien Forest Pest Detection by Counties in the United States
 Version 1.0
 Authors: 
 Songlin Fei, Purdue University
 Randall Morin, US Forest Service
 Shirley Li, Purdue University
 Ningning Kong
 Susan Croker, US Forest Service
 Frank Krist, US Forest Service
 Andrew Liebhold, US Forest Service
 doi:10.4231/HWQF-V087
 
 
 License: 
 CC0 1.0 Universal
 
 #####################################
 Included Publication Materials:
 #####################################
 
Primary File(s): 
>>> AFPE_PEST_2023_counties.csv

Supporting Docs: 
>>> AFPE_PEST_2023_counties_data_dictionary.csv

Image Gallery: 
>>> gallery/AFPE_about-82058.PNG
>>> gallery/AFPE_countymap-82059.PNG

Archival Info:
>>> hubREADME.txt

 
 --------------------------------------------
 Archival package produced 2024-03-28 15:04:41